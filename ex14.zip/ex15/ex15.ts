import { Component } from '@angular/core';

@Component({
  selector: 'app-ex15',
  standalone: false,
  templateUrl: './ex15.html',
  styleUrl: './ex15.css',
})
export class Ex15 {

}
