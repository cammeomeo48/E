import { Component } from '@angular/core';

@Component({
  selector: 'app-ex19',
  standalone: false,
  templateUrl: './ex19.html',
  styleUrl: './ex19.css',
})
export class Ex19 {

}
