import { Component } from '@angular/core';

@Component({
  selector: 'app-service-product',
  standalone: false,
  templateUrl: './service-product.html',
  styleUrl: './service-product.css',
})
export class ServiceProduct {

}
