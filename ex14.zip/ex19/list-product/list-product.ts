import { Component } from '@angular/core';

@Component({
  selector: 'app-list-product',
  standalone: false,
  templateUrl: './list-product.html',
  styleUrl: './list-product.css',
})
export class ListProduct {

}
